# Set working directory
setwd("C://Users//it24104295//Desktop//New folder//it24104295")

# 1. Import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
# Remove the first column which appears to be row numbers
branch_data <- branch_data[,-1]
# Rename columns to match expected names
names(branch_data) <- c("Sales_X1", "Advertising_X2", "Years_X3")

fix(branch_data)
attach(branch_data)

# 2. Identify variable types and scale of measurement
cat("Variable Types and Scale of Measurement:\n")
cat("Sales_X1: Quantitative Continuous, Ratio scale\n")
cat("Advertising_X2: Quantitative Continuous, Ratio scale\n")
cat("Years_X3: Quantitative Discrete, Ratio scale\n\n")

# 3. Boxplot for sales
boxplot(Sales_X1, main="Box Plot for Sales", outline=TRUE, outpch=8, horizontal=TRUE)

# 4. Five number summary and IQR for advertising
cat("Five Number Summary for Advertising:\n")
summary(Advertising_X2)
cat("\nIQR for Advertising:", IQR(Advertising_X2), "\n\n")

# 5. Function to find outliers
get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}

# Check for outliers in years variable
cat("Checking for outliers in Years variable:\n")
get.outliers(Years_X3)

# Detach the dataset
detach(branch_data)
